<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Afterburner2 extends Theme
{

}
