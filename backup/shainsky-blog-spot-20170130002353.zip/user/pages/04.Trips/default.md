---
title: Trips
---

# Let the traveling begin and when I have time...I may write about my experiences!