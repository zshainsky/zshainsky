---
title: Hobbies
---

# Here lives a breathing copy of all of the hobbies I have gotten myself into! 