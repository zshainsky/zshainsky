---
title: 'HACKDFW 2015'
content:
    items: '@self.children'
    limit: '5'
    order:
        by: date
        dir: desc
    pagination: '1'
    url_taxonomy_filters: '1'
---

### What is HackDFW
[HackDFW](http://hackdfw.com/) is a national Hackathon competition held in Dallas, TX. It is an event where teams are given 24 hours to come up with an invention and execute on it. After 24 hours are complete, participants show off their hacks to a set of judges that pick 10 teams to present on a main stage. Once on the main stage, teams will have 5 minutes to once again show off their hacks to an esteemed panel of judges. The panel of judges consisted of Dallas Mavericks owner and entrepreneur Mark Cuban, former Dallas Cowboy Michael Irvin, American Airlines CEO Doug Parker, Dallas Mayor Mike Rawlings, and several others.

### The Story of Runsense
Against all odds, 5 SMU Computer Science students ban together and set out to help runners all across the world! Runsense is a working prototype that is designed to measure the foreces of the foot as a person walks or runs. As a runner there is a need to understand how your feet are striking the ground in order to reduce the risk of injury. The end vision for Runsense would be to implement our technology in a washable sock that anyone could wear and use as they train or simply walk around throughout the day. Feed back to the user is presented via a Pebble watch, which would warn a user if they are either consistently heal striking, over pronating, or under pronating. All of the users steps were recorded and uploaded to a database so users could view their running patterns on a front end web interface. 

### After 24 hours, a lot of thinking, and no sleep
We ended up placing 2nd overall in the competition which won us a trip to South Korea to compete in a global hackathon competition!

